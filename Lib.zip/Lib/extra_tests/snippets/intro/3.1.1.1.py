assert 2 + 2 == 4

assert 50 - 5*6 == 20

assert (50 - 5*6) / 4 == 5 # This will crash
assert (50 - 5*6) / 4 == 5.0

assert 8 / 5 == 1.6 # division always returns a floating point number
