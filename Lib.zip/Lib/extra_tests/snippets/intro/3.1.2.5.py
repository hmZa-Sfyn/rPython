assert 'unununium' == 3 * 'un' + 'ium'
