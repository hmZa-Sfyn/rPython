assert 25 == 5 ** 2  # 5 squared

assert 128 == 2 ** 7  # 2 to the power of 7
