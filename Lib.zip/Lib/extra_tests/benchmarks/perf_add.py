j = 0
while j < 1000:
    total = 0
    i = 0
    while i < 100:
        total += i
        i += 1
    j += 1
