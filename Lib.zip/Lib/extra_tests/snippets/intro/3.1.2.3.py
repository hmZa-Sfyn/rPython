print('C:\some\name')
