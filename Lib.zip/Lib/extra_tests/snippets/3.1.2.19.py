s = "abcdefg"

assert 7 == len(s)
