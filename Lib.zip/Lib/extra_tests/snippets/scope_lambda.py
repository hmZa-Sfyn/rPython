class X:
    v = 10
    f = lambda x=v: x
