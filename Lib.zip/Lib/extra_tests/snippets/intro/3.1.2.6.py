assert 'Python' == 'Py' 'thon'
