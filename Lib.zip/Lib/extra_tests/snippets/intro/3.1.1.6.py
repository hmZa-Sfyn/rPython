assert 7.5 == 3 * 3.75 / 1.5

assert 3.5 == 7.0 / 2
