assert 3 == len([1,2,3])
assert 2 == len((1,2))
