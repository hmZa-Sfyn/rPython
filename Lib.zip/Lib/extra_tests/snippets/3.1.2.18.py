word = "Python"

assert "Jython" == "J" + word[1:]
assert "Pypy" == word[:2] + "py"
