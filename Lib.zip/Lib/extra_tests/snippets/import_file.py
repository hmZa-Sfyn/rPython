import os

def import_file():
	assert os.path.basename(__file__) == "import_file.py"
