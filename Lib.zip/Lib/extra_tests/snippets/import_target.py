# This is used by import.py; the two should be modified in concert

X = '123'
Y = 'abc'

def func():
    return X

def other_func():
    return Y
