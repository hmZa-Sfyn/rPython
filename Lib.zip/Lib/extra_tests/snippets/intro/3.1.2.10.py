word = 'Python'
assert 'P' == word[0]  # character in position 0
assert 'n' == word[5]  # character in position 5
assert 'n' == word[-1]  # last character
assert 'o' == word[-2]  # second-last character
assert 'P' == word[-6]
