import _thread

assert _thread.TIMEOUT_MAX in [9223372036.0, 4294967.0]
