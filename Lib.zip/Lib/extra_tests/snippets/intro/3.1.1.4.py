width = 20
height = 5 * 9
assert 900 == width * height
print(width * height)
