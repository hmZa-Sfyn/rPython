# This is used by import.py; the two should be modified in concert

STAR_IMPORT = '123'
