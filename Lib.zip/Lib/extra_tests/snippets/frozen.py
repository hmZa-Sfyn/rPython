import __hello__
assert __hello__.initialized == True
