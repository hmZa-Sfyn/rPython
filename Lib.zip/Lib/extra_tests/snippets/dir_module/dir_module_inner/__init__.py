from ..relative import value

value2 = value + 2
