def import_func():
    assert __name__ == "import_name"
