word = "Python"
assert "on" == word[4:42]
assert "" == word[42:]
